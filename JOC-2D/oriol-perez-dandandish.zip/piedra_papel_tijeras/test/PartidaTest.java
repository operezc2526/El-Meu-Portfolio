import model.Partida;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class PartidaTest {

    private Partida partida;

    @Before
    public void setUp() {
        partida = new Partida("TestJugador");
    }

    @Test
    public void testNomJugador() {
        assertEquals("TestJugador", partida.getNomJugador());
    }

    @Test
    public void testPartidaNoAcabadaAInici() {
        assertFalse(partida.partidaAcabada());
    }

    @Test
    public void testComptadorsAZeroAInici() {
        assertEquals(0, partida.getRondesJugador());
        assertEquals(0, partida.getRondesMaquina());
    }

    @Test
    public void testEscutGuanyaADisparar() {
        boolean verificat = false;
        for (int i = 0; i < 500; i++) {
            partida = new Partida("TestJugador");
            partida.jugar(Partida.Eleccio.ESCUT);
            if (partida.getEleccioMaquina() == Partida.Eleccio.DISPARAR) {
                assertEquals(Partida.Resultat.VICTORIA, partida.getResultat());
                verificat = true;
                break;
            }
        }
        assertTrue("No s'ha pogut verificar ESCUT vs DISPARAR", verificat);
    }

    @Test
    public void testDispararGuanyaARecargar() {
        boolean verificat = false;
        for (int i = 0; i < 500; i++) {
            partida = new Partida("TestJugador");
            partida.jugar(Partida.Eleccio.DISPARAR);
            if (partida.getEleccioMaquina() == Partida.Eleccio.RECARGAR) {
                assertEquals(Partida.Resultat.VICTORIA, partida.getResultat());
                verificat = true;
                break;
            }
        }
        assertTrue("No s'ha pogut verificar DISPARAR vs RECARGAR", verificat);
    }

    @Test
    public void testRecargarGuanyaAEscut() {
        boolean verificat = false;
        for (int i = 0; i < 500; i++) {
            partida = new Partida("TestJugador");
            partida.jugar(Partida.Eleccio.RECARGAR);
            if (partida.getEleccioMaquina() == Partida.Eleccio.ESCUT) {
                assertEquals(Partida.Resultat.VICTORIA, partida.getResultat());
                verificat = true;
                break;
            }
        }
        assertTrue("No s'ha pogut verificar RECARGAR vs ESCUT", verificat);
    }

    @Test
    public void testEmpatMateixaEleccio() {
        boolean verificat = false;
        for (int i = 0; i < 100; i++) {
            partida = new Partida("TestJugador");
            partida.jugar(Partida.Eleccio.ESCUT);
            if (partida.getEleccioMaquina() == Partida.Eleccio.ESCUT) {
                assertEquals(Partida.Resultat.EMPAT, partida.getResultat());
                verificat = true;
                break;
            }
        }
        assertTrue("No s'ha pogut verificar empat", verificat);
    }

    @Test
    public void testRondesJugadorAugmenten() {
        for (int i = 0; i < 100; i++) {
            partida = new Partida("TestJugador");
            partida.jugar(Partida.Eleccio.ESCUT);
            if (partida.getResultat() == Partida.Resultat.VICTORIA) {
                assertEquals(1, partida.getRondesJugador());
                break;
            }
        }
    }

    @Test
    public void testRondesMaquinaAugmenten() {
        for (int i = 0; i < 100; i++) {
            partida = new Partida("TestJugador");
            partida.jugar(Partida.Eleccio.ESCUT);
            if (partida.getResultat() == Partida.Resultat.DERROTA) {
                assertEquals(1, partida.getRondesMaquina());
                break;
            }
        }
    }
}