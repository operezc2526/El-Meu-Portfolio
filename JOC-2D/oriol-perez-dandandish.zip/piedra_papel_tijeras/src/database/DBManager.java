package database;

import utils.Constants;
import java.sql.*;

/**
 * Classe encarregada de gestionar la connexió i les operacions
 * amb la base de dades MySQL del joc Dan Dan Dish.
 * Proporciona mètodes per connectar, desconnectar i realitzar
 * operacions CRUD sobre la taula de partides.
 */
public class DBManager {

    /**
     * Connexió activa amb la base de dades.
     */
    private Connection connection;

    /**
     * Obre la connexió amb la base de dades MySQL
     * utilitzant els paràmetres definits a {@link utils.Constants}.
     *
     * @throws SQLException si no es pot establir la connexió.
     */
    public void connect() throws SQLException {
        connection = DriverManager.getConnection(
                Constants.DB_URL,
                Constants.DB_USER,
                Constants.DB_PASS);
    }

    /**
     * Tanca la connexió amb la base de dades si està oberta.
     * No llança excepcions — els errors es registren per consola.
     */
    public void disconnect() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Insereix el resum d'una partida acabada a la base de dades.
     *
     * @param nom           Nom del jugador.
     * @param rondesJugador Nombre de rondes guanyades pel jugador.
     * @param rondesMaquina Nombre de rondes guanyades per la màquina.
     * @param resultat      Resultat final de la partida ("VICTORIA" o "DERROTA").
     * @throws SQLException si es produeix un error en la inserció.
     */
    public void insertarPartida(String nom, int rondesJugador,
                                int rondesMaquina, String resultat) throws SQLException {
        String sql = "INSERT INTO partida (nom_jugador, rondes_jugador, " +
                "rondes_maquina, resultat) VALUES (?, ?, ?, ?)";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, nom);
        ps.setInt(2, rondesJugador);
        ps.setInt(3, rondesMaquina);
        ps.setString(4, resultat);
        ps.executeUpdate();
    }

    /**
     * Retorna els 10 millors resultats de totes les partides,
     * ordenats per rondes guanyades de major a menor i
     * per rondes perdudes de menor a major en cas d'empat.
     *
     * @return {@link ResultSet} amb els camps nom_jugador, rondes_jugador,
     *         rondes_maquina, resultat i data.
     * @throws SQLException si es produeix un error en la consulta.
     */
    public ResultSet getRanking() throws SQLException {
        String sql = "SELECT nom_jugador, rondes_jugador, rondes_maquina, " +
                "resultat, data FROM partida " +
                "ORDER BY rondes_jugador DESC, rondes_maquina ASC LIMIT 10";
        return connection.createStatement().executeQuery(sql);
    }
}