package utils;

/**
 * Classe de constants globals del joc Dan Dan Dish.
 * Centralitza els paràmetres de connexió a la base de dades
 * i les regles de joc per facilitar el manteniment del codi.
 */
public class Constants {

    /**
     * URL de connexió a la base de dades MySQL.
     */
    public static final String DB_URL = "jdbc:mysql://localhost:3306/dandandish";

    /**
     * Usuari de la base de dades MySQL.
     */
    public static final String DB_USER = "root";

    /**
     * Contrasenya de la base de dades MySQL.
     */
    public static final String DB_PASS = "oriol2004";

    /**
     * Nombre de rondes necessàries per guanyar la partida.
     */
    public static final int RONDES_PER_GUANYAR = 3;
}