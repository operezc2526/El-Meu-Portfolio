package model;

import utils.Constants;
import java.util.Random;

/**
 * Model principal del joc.
 * Conté la lògica d'una partida completa: gestiona les eleccions
 * del jugador i de la màquina, calcula el resultat de cada ronda
 * i porta el compte de les rondes guanyades per cada banda.
 */
public class Partida {

    /**
     * Enumeració amb les tres accions possibles del joc.
     * ESCUT guanya a DISPARAR, RECARGAR guanya a ESCUT,
     * DISPARAR guanya a RECARGAR.
     */
    public enum Eleccio { ESCUT, RECARGAR, DISPARAR }

    /**
     * Enumeració amb els tres resultats possibles d'una ronda.
     */
    public enum Resultat { VICTORIA, DERROTA, EMPAT }

    /**
     * Nom del jugador humà.
     */
    private String nomJugador;

    /**
     * Elecció feta pel jugador a la ronda actual.
     */
    private Eleccio eleccioJugador;

    /**
     * Elecció generada aleatòriament per la màquina a la ronda actual.
     */
    private Eleccio eleccioMaquina;

    /**
     * Resultat de la ronda actual.
     */
    private Resultat resultat;

    /**
     * Generador de números aleatoris per a les eleccions de la màquina.
     */
    private Random random;

    /**
     * Comptador de rondes guanyades pel jugador.
     */
    private int rondesJugador;

    /**
     * Comptador de rondes guanyades per la màquina.
     */
    private int rondesMaquina;

    /**
     * Crea una nova partida per al jugador indicat.
     * Inicialitza els comptadors de rondes a zero.
     *
     * @param nomJugador Nom del jugador humà.
     */
    public Partida(String nomJugador) {
        this.nomJugador = nomJugador;
        this.random = new Random();
        this.rondesJugador = 0;
        this.rondesMaquina = 0;
    }

    /**
     * Processa una ronda del joc amb l'elecció del jugador.
     * Genera l'elecció de la màquina, calcula el resultat
     * i actualitza els comptadors de rondes.
     *
     * @param eleccio Acció triada pel jugador (ESCUT, RECARGAR o DISPARAR).
     */
    public void jugar(Eleccio eleccio) {
        this.eleccioJugador = eleccio;
        this.eleccioMaquina = generarEleccioMaquina();
        this.resultat = calcularResultat();

        if (resultat == Resultat.VICTORIA) {
            rondesJugador++;
        } else if (resultat == Resultat.DERROTA) {
            rondesMaquina++;
        }
    }

    /**
     * Genera aleatòriament una de les tres accions possibles per a la màquina.
     *
     * @return {@link Eleccio} aleatòria de la màquina.
     */
    private Eleccio generarEleccioMaquina() {
        int num = random.nextInt(3);
        if (num == 0) {
            return Eleccio.ESCUT;
        } else if (num == 1) {
            return Eleccio.RECARGAR;
        } else {
            return Eleccio.DISPARAR;
        }
    }

    /**
     * Calcula el resultat de la ronda comparant les eleccions
     * del jugador i de la màquina segons les regles del joc:
     * ESCUT guanya a DISPARAR, RECARGAR guanya a ESCUT,
     * DISPARAR guanya a RECARGAR.
     *
     * @return {@link Resultat} de la ronda (VICTORIA, DERROTA o EMPAT).
     */
    private Resultat calcularResultat() {
        if (eleccioJugador == eleccioMaquina) {
            return Resultat.EMPAT;
        } else if (eleccioJugador == Eleccio.ESCUT
                && eleccioMaquina == Eleccio.DISPARAR) {
            return Resultat.VICTORIA;
        } else if (eleccioJugador == Eleccio.RECARGAR
                && eleccioMaquina == Eleccio.ESCUT) {
            return Resultat.VICTORIA;
        } else if (eleccioJugador == Eleccio.DISPARAR
                && eleccioMaquina == Eleccio.RECARGAR) {
            return Resultat.VICTORIA;
        } else {
            return Resultat.DERROTA;
        }
    }

    /**
     * Comprova si la partida ha acabat.
     * La partida acaba quan el jugador o la màquina arriba
     * al nombre de rondes definit a {@link Constants#RONDES_PER_GUANYAR}.
     *
     * @return {@code true} si la partida ha acabat, {@code false} si continua.
     */
    public boolean partidaAcabada() {
        return rondesJugador >= Constants.RONDES_PER_GUANYAR
                || rondesMaquina >= Constants.RONDES_PER_GUANYAR;
    }

    /**
     * Retorna el nom del jugador.
     *
     * @return Nom del jugador.
     */
    public String getNomJugador() { return nomJugador; }

    /**
     * Retorna l'elecció feta pel jugador a la ronda actual.
     *
     * @return {@link Eleccio} del jugador.
     */
    public Eleccio getEleccioJugador() { return eleccioJugador; }

    /**
     * Retorna l'elecció generada per la màquina a la ronda actual.
     *
     * @return {@link Eleccio} de la màquina.
     */
    public Eleccio getEleccioMaquina() { return eleccioMaquina; }

    /**
     * Retorna el resultat de la ronda actual.
     *
     * @return {@link Resultat} de la ronda.
     */
    public Resultat getResultat() { return resultat; }

    /**
     * Retorna el nombre de rondes guanyades pel jugador.
     *
     * @return Rondes guanyades pel jugador.
     */
    public int getRondesJugador() { return rondesJugador; }

    /**
     * Retorna el nombre de rondes guanyades per la màquina.
     *
     * @return Rondes guanyades per la màquina.
     */
    public int getRondesMaquina() { return rondesMaquina; }
}