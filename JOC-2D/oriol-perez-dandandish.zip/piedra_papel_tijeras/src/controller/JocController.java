package controller;

import model.Partida;
import view.JocFrame;
import database.DBManager;
import utils.Constants;
import java.sql.ResultSet;
import javax.swing.*;

/**
 * Controlador principal del joc Dan Dan Dish.
 * Gestiona el flux de la partida coordinant el model {@link Partida},
 * la vista {@link JocFrame} i la capa de dades {@link DBManager}.
 * Rep les accions del jugador, actualitza la vista i
 * finalitza la partida quan un dels dos arriba a {@link Constants#RONDES_PER_GUANYAR}.
 */
public class JocController {

    /**
     * Model que conté la lògica i l'estat de la partida en curs.
     */
    private Partida partida;

    /**
     * Vista principal del joc on es mostren els resultats i els botons d'acció.
     */
    private JocFrame jocFrame;

    /**
     * Gestor de la connexió i les operacions amb la base de dades.
     */
    private DBManager dbManager;

    /**
     * Crea el controlador, inicialitza el model, connecta la base de dades
     * i obre la finestra principal del joc.
     *
     * @param nomJugador Nom del jugador introduït al menú inicial.
     */
    public JocController(String nomJugador) {
        this.partida = new Partida(nomJugador);

        connectarBD();

        jocFrame = new JocFrame(this, nomJugador);
    }

    /**
     * Estableix la connexió amb la base de dades MySQL.
     * Si la connexió falla, mostra un diàleg d'error i tanca l'aplicació.
     */
    private void connectarBD() {
        dbManager = new DBManager();
        try {
            dbManager.connect();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Error de connexió: " + e.getMessage(),
                    "Error BD",
                    JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    /**
     * Processa l'elecció del jugador per a una ronda.
     * Delega el càlcul del resultat al model {@link Partida},
     * actualitza la vista amb el resultat obtingut i
     * comprova si la partida ha acabat.
     *
     * @param eleccio Acció triada pel jugador (DISPARAR, RECARGAR o ESCUT).
     */
    public void jugar(Partida.Eleccio eleccio) {
        partida.jugar(eleccio);
        jocFrame.actualitzarUI(
                partida.getEleccioJugador(),
                partida.getEleccioMaquina(),
                partida.getResultat(),
                partida.getRondesJugador(),
                partida.getRondesMaquina()
        );

        if (partida.partidaAcabada()) {
            acabarPartida();
        }
    }

    /**
     * Finalitza la partida quan un dels dos arriba al nombre de rondes
     * necessàries per guanyar definit a {@link Constants#RONDES_PER_GUANYAR}.
     * Guarda el resultat a la base de dades, mostra un diàleg amb el resum
     * i tanca l'aplicació.
     * Mostra el ranking de les partides anteriors
     */
    private void acabarPartida() {
        String resultat;
        if (partida.getRondesJugador() >= Constants.RONDES_PER_GUANYAR) {
            resultat = "VICTORIA";
        } else {
            resultat = "DERROTA";
        }

        try {
            dbManager.insertarPartida(
                    partida.getNomJugador(),
                    partida.getRondesJugador(),
                    partida.getRondesMaquina(),
                    resultat);
        } catch (Exception e) {
            e.printStackTrace();
        }

        StringBuilder ranking = new StringBuilder();
        ranking.append("--- TOP 10 RANKING ---\n\n");

        try {
            ResultSet rs = dbManager.getRanking();
            int pos = 1;
            while (rs.next()) {
                ranking.append(pos + ". ")
                        .append(rs.getString("nom_jugador"))
                        .append(" | W: ").append(rs.getInt("rondes_jugador"))
                        .append(" L: ").append(rs.getInt("rondes_maquina"))
                        .append(" | ").append(rs.getString("resultat"))
                        .append("\n");
                pos++;
            }
            dbManager.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JOptionPane.showMessageDialog(null,
                resultat + "\n\n" + ranking.toString(),
                "Fi de la partida",
                JOptionPane.INFORMATION_MESSAGE);

        System.exit(0);
    }

    /**
     * Retorna el model de la partida en curs.
     *
     * @return {@link Partida} amb l'estat actual de la partida.
     */
    public Partida getPartida() {
        return partida;
    }
}