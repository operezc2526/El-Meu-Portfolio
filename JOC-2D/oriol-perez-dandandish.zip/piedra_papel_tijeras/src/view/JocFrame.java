package view;

import controller.JocController;
import model.Partida;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Finestra principal del joc Dan Dan Dish.
 * Mostra el marcador de rondes, el resultat de cada ronda
 * i els tres botons d'acció del jugador (Disparar, Recargar, Escut).
 * S'actualitza després de cada ronda mitjançant {@link #actualitzarUI}.
 */
public class JocFrame extends JFrame {

    /**
     * Referència al controlador del joc per delegar les accions del jugador.
     */
    private JocController controller;

    /**
     * Etiqueta que mostra el marcador de rondes guanyades de cada banda.
     */
    private JLabel labelRondes;

    /**
     * Etiqueta que mostra el resultat de la ronda actual (VICTÒRIA, DERROTA o EMPAT).
     */
    private JLabel labelResultat;

    /**
     * Etiqueta que mostra l'elecció feta pel jugador a la ronda actual.
     */
    private JLabel labelEleccioJugador;

    /**
     * Etiqueta que mostra l'elecció feta per la màquina a la ronda actual.
     */
    private JLabel labelEleccioMaquina;

    /**
     * Botó per triar l'acció Disparar.
     */
    private JButton botoDisparar;

    /**
     * Botó per triar l'acció Recargar.
     */
    private JButton botoRecargar;

    /**
     * Botó per triar l'acció Escut.
     */
    private JButton botoEscut;

    /**
     * Crea i mostra la finestra principal del joc.
     * Inicialitza els tres panells (info, resultat i botons)
     * i els distribueix amb {@link BorderLayout}.
     *
     * @param controller  Controlador del joc que gestiona la lògica de cada ronda.
     * @param nomJugador  Nom del jugador, mostrat a la barra de títol de la finestra.
     */
    public JocFrame(JocController controller, String nomJugador) {
        this.controller = controller;

        setTitle("DAN DAN DISH - " + nomJugador);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout(10, 10));

        add(crearPanellInfo(), BorderLayout.NORTH);
        add(crearPanellResultat(), BorderLayout.CENTER);
        add(crearPanellBotons(), BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * Crea el panell superior amb el marcador de rondes.
     * Utilitza {@link FlowLayout} per centrar l'etiqueta horitzontalment.
     *
     * @return {@link JPanel} amb el marcador de rondes.
     */
    private JPanel crearPanellInfo() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.DARK_GRAY);
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        labelRondes = new JLabel("JUGADOR: 0  |  MÀQUINA: 0");
        labelRondes.setForeground(Color.YELLOW);
        labelRondes.setFont(new Font("Monospaced", Font.BOLD, 16));

        panel.add(labelRondes);
        return panel;
    }

    /**
     * Crea el panell central amb les etiquetes de resultat de la ronda.
     * Mostra l'elecció del jugador, l'elecció de la màquina
     * i el resultat de la ronda en curs.
     * Utilitza {@link GridLayout} per apilar les tres etiquetes verticalment.
     *
     * @return {@link JPanel} amb les etiquetes de resultat.
     */
    private JPanel crearPanellResultat() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.BLACK);
        panel.setLayout(new GridLayout(3, 1, 5, 5));

        labelEleccioJugador = new JLabel("Tu: ---", SwingConstants.CENTER);
        labelEleccioJugador.setForeground(Color.WHITE);
        labelEleccioJugador.setFont(new Font("Monospaced", Font.PLAIN, 14));

        labelEleccioMaquina = new JLabel("Màquina: ---", SwingConstants.CENTER);
        labelEleccioMaquina.setForeground(Color.WHITE);
        labelEleccioMaquina.setFont(new Font("Monospaced", Font.PLAIN, 14));

        labelResultat = new JLabel("Tria una acció!", SwingConstants.CENTER);
        labelResultat.setForeground(Color.CYAN);
        labelResultat.setFont(new Font("Monospaced", Font.BOLD, 20));

        panel.add(labelEleccioJugador);
        panel.add(labelEleccioMaquina);
        panel.add(labelResultat);

        return panel;
    }

    /**
     * Crea el panell inferior amb els tres botons d'acció del jugador.
     * Cada botó delega l'acció al {@link JocController} en ser premut.
     * Utilitza {@link GridLayout} per col·locar els botons en una fila.
     *
     * @return {@link JPanel} amb els tres botons d'acció.
     */
    private JPanel crearPanellBotons() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.DARK_GRAY);
        panel.setLayout(new GridLayout(1, 3, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        botoDisparar = new JButton("🔫 DISPARAR");
        botoDisparar.setBackground(new Color(233, 69, 96));
        botoDisparar.setForeground(Color.WHITE);
        botoDisparar.setFont(new Font("Monospaced", Font.BOLD, 14));
        botoDisparar.setFocusPainted(false);
        botoDisparar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.jugar(Partida.Eleccio.DISPARAR);
            }
        });

        botoRecargar = new JButton("🔄 RECARGAR");
        botoRecargar.setBackground(new Color(245, 166, 35));
        botoRecargar.setForeground(Color.WHITE);
        botoRecargar.setFont(new Font("Monospaced", Font.BOLD, 14));
        botoRecargar.setFocusPainted(false);
        botoRecargar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.jugar(Partida.Eleccio.RECARGAR);
            }
        });

        botoEscut = new JButton("🛡️ ESCUT");
        botoEscut.setBackground(new Color(15, 52, 96));
        botoEscut.setForeground(Color.WHITE);
        botoEscut.setFont(new Font("Monospaced", Font.BOLD, 14));
        botoEscut.setFocusPainted(false);
        botoEscut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.jugar(Partida.Eleccio.ESCUT);
            }
        });

        panel.add(botoDisparar);
        panel.add(botoRecargar);
        panel.add(botoEscut);

        return panel;
    }

    /**
     * Actualitza la interfície gràfica amb el resultat de la ronda acabada.
     * Canvia el text i el color de les etiquetes segons el resultat:
     * verd per a victòria, vermell per a derrota i groc per a empat.
     *
     * @param eleccioJugador  Elecció feta pel jugador aquesta ronda.
     * @param eleccioMaquina  Elecció feta per la màquina aquesta ronda.
     * @param resultat        Resultat de la ronda (VICTORIA, DERROTA o EMPAT).
     * @param rondesJugador   Rondes guanyades acumulades pel jugador.
     * @param rondesMaquina   Rondes guanyades acumulades per la màquina.
     */
    public void actualitzarUI(Partida.Eleccio eleccioJugador,
                              Partida.Eleccio eleccioMaquina,
                              Partida.Resultat resultat,
                              int rondesJugador, int rondesMaquina) {

        labelEleccioJugador.setText("Tu: " + eleccioJugador.toString());
        labelEleccioMaquina.setText("Màquina: " + eleccioMaquina.toString());
        labelRondes.setText("JUGADOR: " + rondesJugador + "  |  MÀQUINA: " + rondesMaquina);

        if (resultat == Partida.Resultat.VICTORIA) {
            labelResultat.setForeground(Color.GREEN);
            labelResultat.setText("✓ VICTÒRIA!");
        } else if (resultat == Partida.Resultat.DERROTA) {
            labelResultat.setForeground(Color.RED);
            labelResultat.setText("✗ DERROTA!");
        } else {
            labelResultat.setForeground(Color.YELLOW);
            labelResultat.setText("= EMPAT!");
        }
    }
}