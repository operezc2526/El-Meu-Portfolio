package view;

import main.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Finestra inicial del joc Dan Dan Dish.
 * Permet al jugador introduir el seu nom abans de començar la partida.
 * Valida que el camp no estigui buit i delega l'inici del joc a {@link Main#iniciarJoc}.
 */
public class MenuNom extends JFrame {

    /**
     * Camp de text on el jugador introdueix el seu nom.
     */
    private JTextField campNom;

    /**
     * Botó per confirmar el nom i iniciar la partida.
     */
    private JButton botoJugar;

    /**
     * Crea i mostra la finestra del menú inicial.
     * Utilitza {@link GridLayout} per organitzar l'etiqueta,
     * el camp de text i el botó en una quadrícula de 3 files i 2 columnes.
     */
    public MenuNom() {
        setTitle("DAN DAN DISH");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new GridLayout(3, 2, 10, 10));

        JLabel labelNom = new JLabel("Introdueix el teu nom:");
        campNom = new JTextField();

        botoJugar = new JButton("Jugar");
        botoJugar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comprovarNom();
            }
        });

        add(labelNom);
        add(campNom);
        add(new JLabel());
        add(botoJugar);

        setSize(350, 150);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * Valida el nom introduït pel jugador.
     * Si el camp està buit mostra un diàleg d'error.
     * Si el nom és vàlid tanca aquesta finestra i crida
     * {@link Main#iniciarJoc} per iniciar la partida.
     */
    private void comprovarNom() {
        String nom = campNom.getText().trim();

        if (nom.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Has d'introduir un nom!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        } else {
            dispose();
            Main.iniciarJoc(nom);
        }
    }
}