package main;

import controller.JocController;
import view.MenuNom;

import javax.swing.SwingUtilities;

/**
 * Classe principal del joc Dan Dan Dish.
 * Conté el punt d'entrada de l'aplicació i el mètode
 * per iniciar el joc un cop el jugador ha introduït el seu nom.
 * Totes les operacions sobre components Swing es delguen
 * al EDT (Event Dispatch Thread) mitjançant {@link SwingUtilities#invokeLater}.
 */
public class Main {

    /**
     * Punt d'entrada de l'aplicació.
     * Obre la finestra del menú inicial {@link MenuNom}
     * dins del EDT per garantir la seguretat de fils de Swing.
     *
     * @param args Arguments de línia de comandes (no s'utilitzen).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MenuNom();
            }
        });
    }

    /**
     * Inicia el joc creant el {@link JocController} amb el nom del jugador.
     * S'executa dins del EDT per garantir la seguretat de fils de Swing.
     * És cridat per {@link view.MenuNom} quan el jugador confirma el seu nom.
     *
     * @param nomJugador Nom introduït pel jugador al menú inicial.
     */
    public static void iniciarJoc(String nomJugador) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new JocController(nomJugador);
            }
        });
    }
}