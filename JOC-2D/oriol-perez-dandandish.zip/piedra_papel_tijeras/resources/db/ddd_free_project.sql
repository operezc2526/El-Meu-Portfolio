CREATE DATABASE IF NOT EXISTS dandandish;
USE dandandish;

CREATE TABLE partida (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    nom_jugador   VARCHAR(50) NOT NULL,
    rondes_jugador INT NOT NULL,
    rondes_maquina INT NOT NULL,
    resultat      ENUM('VICTORIA','DERROTA') NOT NULL,
    data          DATETIME DEFAULT CURRENT_TIMESTAMP
);